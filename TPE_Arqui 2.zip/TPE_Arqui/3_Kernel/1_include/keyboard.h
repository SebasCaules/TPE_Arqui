#ifndef KEYBOARD_H_
#define KEYBOARD_H_

extern int getPressedKey();

void pressedKey();

unsigned char bufferNext();

#endif