#!/bin/bash
qemu-system-x86_64 -hda 1_Image/x64BareBonesImage.qcow2 -m 512 
